<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: user/dashboard.php');
    exit;
}
if (isset($_SESSION['admin_id'])) {
    header('Location: admin/dashboard.php');
    exit;
}
include 'includes/header.php';
?>
<div class="home-page">
  <section class="hero">
    <h2>Welcome to the College Management Portal</h2>
    <p>Access student tools, manage users, and keep activity logs in one place.</p>
    <div class="hero-links">
      <a href="/user/login.php" class="button">Student Login</a>
      <a href="/user/register.php" class="button secondary">Register</a>
      <a href="/admin/login.php" class="button tertiary">Admin Login</a>
    </div>
  </section>
</div>
<?php include 'includes/footer.php'; ?>