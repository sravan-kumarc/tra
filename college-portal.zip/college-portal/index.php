<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header('Location: user/dashboard.php');
    exit;
}
if (isset($_SESSION['admin_id'])) {
    header('Location: admin/dashboard.php');
    exit;
}
include 'includes/header.php';
?>
<div class="home-page">
  <section class="hero">
    <h2>Welcome to College Portal</h2>
    <p>Streamline your academic journey with our comprehensive management system. Access assignments, track progress, and manage your educational experience all in one place.</p>
    <div class="hero-links">
      <a href="/user/login.php" class="button">🔐 Student Login</a>
      <a href="/user/register.php" class="button secondary">📝 Join Now</a>
      <a href="/admin/login.php" class="button tertiary">🛡️ Admin Access</a>
    </div>
  </section>

  <div class="features-grid">
    <div class="feature-card">
      <div class="feature-icon">📚</div>
      <h3>Course Management</h3>
      <p>Enroll in courses and track your academic progress with ease.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">📝</div>
      <h3>Assignment Tracking</h3>
      <p>Stay on top of your assignments with due dates and status updates.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">👤</div>
      <h3>Profile Management</h3>
      <p>Update your personal information and academic details anytime.</p>
    </div>
    <div class="feature-card">
      <div class="feature-icon">📊</div>
      <h3>Admin Dashboard</h3>
      <p>Comprehensive tools for administrators to manage students and assignments.</p>
    </div>
  </div>
</div>
<?php include 'includes/footer.php'; ?>