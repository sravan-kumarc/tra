document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form");
  if (!form) {
    return;
  }

  const username = document.getElementById("username");
  const password = document.getElementById("password");

  if (!username || !password) {
    return;
  }

  form.addEventListener("submit", (e) => {
    if (!username.value.trim() || !password.value.trim()) {
      e.preventDefault();
      alert("Please fill in both fields.");
    }
  });
});
