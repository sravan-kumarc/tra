// Modern College Portal JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // Form validation and enhancement
  const forms = document.querySelectorAll("form");

  forms.forEach(form => {
    const submitButton = form.querySelector('button[type="submit"]');
    if (!submitButton) return;

    // Add loading state to forms
    form.addEventListener("submit", (e) => {
      const isValid = validateForm(form);
      if (!isValid) {
        e.preventDefault();
        return;
      }

      // Add loading state
      submitButton.classList.add('loading');
      submitButton.textContent = 'Processing...';
      submitButton.disabled = true;
    });
  });

  // Enhanced form validation
  function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;

    inputs.forEach(input => {
      if (!input.value.trim()) {
        showError(input, 'This field is required');
        isValid = false;
      } else {
        clearError(input);
      }

      // Email validation
      if (input.type === 'email' && input.value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(input.value)) {
          showError(input, 'Please enter a valid email address');
          isValid = false;
        }
      }

      // Password validation
      if (input.type === 'password' && input.value) {
        if (input.value.length < 6) {
          showError(input, 'Password must be at least 6 characters long');
          isValid = false;
        }
      }

      // GPA validation
      if (input.name === 'gpa' && input.value) {
        const gpa = parseFloat(input.value);
        if (gpa < 0 || gpa > 4) {
          showError(input, 'GPA must be between 0 and 4');
          isValid = false;
        }
      }
    });

    return isValid;
  }

  function showError(input, message) {
    clearError(input);
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error';
    errorDiv.textContent = message;
    errorDiv.style.cssText = `
      color: var(--danger-color);
      font-size: 0.875rem;
      margin-top: 0.25rem;
      font-weight: 500;
    `;
    input.parentNode.appendChild(errorDiv);
    input.style.borderColor = 'var(--danger-color)';
  }

  function clearError(input) {
    const existingError = input.parentNode.querySelector('.field-error');
    if (existingError) {
      existingError.remove();
    }
    input.style.borderColor = '';
  }

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  // Enhanced table interactions
  const tables = document.querySelectorAll('.data-table');
  tables.forEach(table => {
    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(row => {
      row.addEventListener('click', () => {
        // Remove previous selection
        table.querySelectorAll('tbody tr.selected').forEach(selectedRow => {
          selectedRow.classList.remove('selected');
        });
        // Add selection to clicked row
        row.classList.add('selected');
      });
    });
  });

  // Add CSS for selected table rows
  const style = document.createElement('style');
  style.textContent = `
    .data-table tbody tr.selected {
      background: rgba(99, 102, 241, 0.1) !important;
      border-left: 4px solid var(--primary-color);
    }
  `;
  document.head.appendChild(style);

  // Auto-hide alerts after 5 seconds
  const alerts = document.querySelectorAll('.alert');
  alerts.forEach(alert => {
    setTimeout(() => {
      alert.style.opacity = '0';
      alert.style.transform = 'translateY(-20px)';
      setTimeout(() => {
        if (alert.parentNode) {
          alert.parentNode.removeChild(alert);
        }
      }, 300);
    }, 5000);
  });

  // Mobile menu toggle (if needed in future)
  function initMobileMenu() {
    const nav = document.querySelector('nav');
    if (!nav) return;

    // Create mobile menu button
    const mobileMenuBtn = document.createElement('button');
    mobileMenuBtn.className = 'mobile-menu-btn';
    mobileMenuBtn.innerHTML = '☰';
    mobileMenuBtn.style.cssText = `
      display: none;
      background: none;
      border: none;
      color: white;
      font-size: 1.5rem;
      cursor: pointer;
      padding: 0.5rem;
    `;

    // Insert before nav
    nav.parentNode.insertBefore(mobileMenuBtn, nav);

    // Toggle mobile menu
    mobileMenuBtn.addEventListener('click', () => {
      nav.classList.toggle('mobile-menu-open');
    });

    // Show/hide mobile button based on screen size
    function checkScreenSize() {
      if (window.innerWidth <= 768) {
        mobileMenuBtn.style.display = 'block';
        nav.classList.add('mobile-menu');
      } else {
        mobileMenuBtn.style.display = 'none';
        nav.classList.remove('mobile-menu', 'mobile-menu-open');
      }
    }

    window.addEventListener('resize', checkScreenSize);
    checkScreenSize();
  }

  initMobileMenu();

  // Add loading animation to buttons
  const buttons = document.querySelectorAll('button, .button, .action-card');
  buttons.forEach(button => {
    button.addEventListener('click', function() {
      if (this.form || this.classList.contains('action-card')) {
        this.style.transform = 'scale(0.98)';
        setTimeout(() => {
          this.style.transform = '';
        }, 150);
      }
    });
  });

  // Add fade-in animation to cards
  const cards = document.querySelectorAll('.card-form, .profile-card, .stat-card, .feature-card');
  cards.forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    setTimeout(() => {
      card.style.transition = 'all 0.5s ease';
      card.style.opacity = '1';
      card.style.transform = 'translateY(0)';
    }, index * 100);
  });

  // Password strength indicator
  const passwordInputs = document.querySelectorAll('input[type="password"]');
  passwordInputs.forEach(input => {
    input.addEventListener('input', function() {
      const strength = calculatePasswordStrength(this.value);
      updatePasswordStrengthIndicator(this, strength);
    });
  });

  function calculatePasswordStrength(password) {
    let strength = 0;
    if (password.length >= 8) strength++;
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/[0-9]/.test(password)) strength++;
    if (/[^A-Za-z0-9]/.test(password)) strength++;
    return strength;
  }

  function updatePasswordStrengthIndicator(input, strength) {
    let existingIndicator = input.parentNode.querySelector('.password-strength');
    if (existingIndicator) {
      existingIndicator.remove();
    }

    if (strength > 0) {
      const indicator = document.createElement('div');
      indicator.className = 'password-strength';
      indicator.style.cssText = `
        margin-top: 0.25rem;
        font-size: 0.75rem;
        font-weight: 500;
      `;

      const colors = ['#ef4444', '#f59e0b', '#eab308', '#84cc16', '#22c55e'];
      const labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];

      indicator.textContent = labels[strength - 1] || 'Very Weak';
      indicator.style.color = colors[strength - 1] || colors[0];

      input.parentNode.appendChild(indicator);
    }
  }

  // Confirm delete actions
  const deleteButtons = document.querySelectorAll('button[onclick*="delete"], a[href*="delete"]');
  deleteButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
        e.preventDefault();
      }
    });
  });

  console.log('🎓 College Portal UI enhancements loaded successfully!');
});
