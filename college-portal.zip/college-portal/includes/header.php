<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>College Management Portal</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/style.css">
  <script defer src="/assets/js/script.js"></script>
</head>
<body>
<header>
  <div class="header-inner">
    <h1>🎓 College Portal</h1>
    <nav>
      <a href="/index.php">🏠 Home</a>
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="/user/dashboard.php">📊 Dashboard</a>
        <a href="/user/update_profile.php">👤 Profile</a>
        <a href="/user/logout.php">🚪 Logout</a>
      <?php elseif (isset($_SESSION['admin_id'])): ?>
        <a href="/admin/dashboard.php">⚙️ Admin</a>
        <a href="/admin/manage_users.php">👥 Students</a>
        <a href="/admin/manage_assignments.php">📝 Assignments</a>
        <a href="/admin/view_logs.php">📋 Logs</a>
        <a href="/admin/logout.php">🚪 Logout</a>
      <?php else: ?>
        <a href="/user/login.php">🔐 Student Login</a>
        <a href="/user/register.php">📝 Register</a>
        <a href="/admin/login.php">🛡️ Admin Login</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main class="page-container">
