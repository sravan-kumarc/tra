<?php
function logAction($pdo, $action, $user_id = null, $admin_id = null) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $stmt = $pdo->prepare("INSERT INTO logs (user_id, admin_id, action, ip_address) VALUES (?,?,?,?)");
    $stmt->execute([$user_id, $admin_id, $action, $ip]);
}
?>
