<?php
function sendEmail($to, $subject, $body) {
    $from = $_ENV['MAIL_FROM'] ?? 'no-reply@localhost';
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type: text/html; charset=utf-8" . "\r\n";
    $headers .= "From: College Portal <" . $from . ">" . "\r\n";
    
    if (function_exists('mail')) {
        return mail($to, $subject, $body, $headers);
    }

    error_log("Mail() not available. Failed to send email to $to.");
    return false;
}
?>
