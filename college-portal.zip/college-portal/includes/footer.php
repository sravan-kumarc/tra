  </main>
  <footer>
    <div class="footer-inner">
      <div class="footer-content">
        <div class="footer-section">
          <h4>🎓 College Portal</h4>
          <p>Empowering education through technology. Manage your academic journey with ease.</p>
        </div>
        <div class="footer-section">
          <h4>Quick Links</h4>
          <ul>
            <li><a href="/index.php">Home</a></li>
            <li><a href="/user/register.php">Student Registration</a></li>
            <li><a href="/admin/login.php">Admin Access</a></li>
          </ul>
        </div>
        <div class="footer-section">
          <h4>Support</h4>
          <ul>
            <li><a href="/user/forgot_password.php">Reset Password</a></li>
            <li><a href="/admin/view_logs.php">System Logs</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; <?= date('Y') ?> College Management Portal. Built with ❤️ for education.</p>
      </div>
    </div>
  </footer>
</body>
</html>
