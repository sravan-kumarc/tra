</main>
<footer>
  <div class="footer-inner">
    <p>College Management Portal &copy; <?= date('Y') ?></p>
  </div>
</footer>
</body>
</html>
