# College Management Portal

This application is a simple college management portal with student and admin access.

## Features
- Student registration and login
- Student profile dashboard
- Profile update page
- Password reset flow
- Admin login
- Student management (add / edit / delete)
- Activity log viewer

## Setup
1. Copy `.env.example` to `.env` and update database credentials.
2. Import `database.sql` into your MySQL database.
3. Place the project under a PHP-capable web server root.
4. Open `/index.php` in your browser.

## Default Admin
- Username: `admin`
- Password: `password`

## Notes
- The app loads configuration from `.env` if present.
- Email reset uses PHP `mail()` by default.
