# College Management Portal

This application is a simple college management portal with student and admin access, built with PHP and MySQL.

## Features
- Student registration and login
- Student profile dashboard
- Profile update page
- Password reset flow
- Admin login
- Student management (add / edit / delete)
- Activity log viewer
- Pre-configured courses: Computer Science, Mechanical Engineering, Electrical Engineering, Civil Engineering, Business Administration, Medicine

## Prerequisites

### For Local Development (WSL/Windows)
- WSL (Windows Subsystem for Linux) with Ubuntu
- PHP 8.0 or higher
- MySQL 5.7 or higher (or MariaDB)
- Git (optional, for cloning)

### For AWS Deployment
- AWS account
- EC2 instance (Amazon Linux 2 or Ubuntu)
- RDS MySQL instance
- SSH access to EC2

## Installation

### Option 1: Local Setup (WSL)

1. **Install PHP and MySQL in WSL**:
   ```bash
   sudo apt update
   sudo apt install php php-mysql mysql-server
   sudo systemctl start mysql
   sudo systemctl enable mysql
   ```

2. **Clone or copy the project**:
   ```bash
   cd ~
   git clone https://github.com/your-repo/college-portal.git
   cd college-portal
   ```

3. **Configure the database**:
   - Import the database schema and data:
     ```bash
     sudo mysql < database.sql
     ```

4. **Configure environment**:
   - Copy `.env.example` to `.env`:
     ```bash
     cp .env.example .env
     ```
   - Edit `.env` with your local MySQL credentials:
     ```env
     DB_HOST=127.0.0.1
     DB_USER=root
     DB_PASSWORD=your_mysql_root_password
     DB_NAME=college_portal
     MAIL_FROM=no-reply@localhost
     ```

### Option 2: AWS EC2 with RDS

1. **Create RDS MySQL Instance**:
   - Go to AWS Console → RDS → Create database
   - Engine: MySQL
   - DB instance identifier: `college-portal-db`
   - Master username: `college_admin`
   - Master password: Choose a strong password #Sravan12345
   - DB name: `college_portal`
   - VPC: Same as your EC2 instance
   - Security group: Allow MySQL/Aurora (port 3306) from EC2 security group

2. **Launch EC2 Instance**:
   - AMI: Amazon Linux 2023 or Ubuntu 24.04
   - Instance type: t3.micro (free tier)
   - Security group: Allow SSH (22) and HTTP (80)
   - Key pair: Create or use existing

3. **Connect to EC2**:
   ```bash
   ssh -i your-key.pem ec2-user@your-ec2-public-ip
   ```

4. **Install Software on EC2**:
   For Amazon Linux:
   ```bash
   sudo dnf update -y
   sudo dnf install -y httpd php php-mysqlnd mariadb105 unzip
   sudo systemctl enable --now httpd
   ```
   For Ubuntu:
   ```bash
   sudo apt update
   sudo apt install -y apache2 php php-mysql unzip
   ```

5. **Upload Project Files**:
   - Use `scp` or upload via AWS console:
     ```bash
     scp -i your-key.pem -r college-portal ec2-user@your-ec2-public-ip:/home/ec2-user/
     ```
   - Move to web root:
     ```bash
     sudo mv college-portal/* /var/www/html/
     ```


6. **Configure Database on EC2**:
   - Install MySQL client:
     ```bash
     sudo dnf install -y mariadb  # Amazon Linux (if not already installed)
     # or sudo apt install -y default-mysql-client  # Ubuntu
     ```
   - Import the database schema and data:
     ```bash
     mysql -h your-rds-endpoint.rds.amazonaws.com -u college_admin -p < /var/www/html/database.sql
     ```

7. **Configure Environment on EC2**:
   - Edit `.env`:
     ```bash
     sudo nano /var/www/html/.env
     ```
     Set:
     ```env
     DB_HOST=your-rds-endpoint.rds.amazonaws.com
     DB_USER=college_admin
     DB_PASSWORD=your_rds_password
     DB_NAME=college_portal
     MAIL_FROM=no-reply@localhost
     ```
   - Set permissions:
     ```bash
     sudo chown -R apache:apache /var/www/html  # Amazon Linux
     # or sudo chown -R www-data:www-data /var/www/html  # Ubuntu
     ```

## Launching the Application

### Local Launch
1. Start PHP built-in server:
   ```bash
   cd ~/college-portal
   php -S localhost:8000
   ```
2. Open in browser: `http://localhost:8000`

### AWS Launch
1. Restart web server:
   ```bash
   sudo systemctl restart httpd  # Amazon Linux
   # or sudo systemctl restart apache2  # Ubuntu
   ```
2. Open in browser: `http://your-ec2-public-ip`

## Usage

- **Home Page**: `http://your-domain/`
- **Student Registration**: `/user/register.php`
- **Student Login**: `/user/login.php`
- **Student Dashboard**: `/user/dashboard.php` (after login)
- **Admin Login**: `/admin/login.php`
- **Admin Dashboard**: `/admin/dashboard.php` (after login)

## Default Credentials

- **Admin**:
  - Username: `admin`
  - Password: `password`

## Notes
- The app loads configuration from `.env` if present.
- Email reset uses PHP `mail()` by default (configure SMTP for production).
- Courses are pre-configured in the database and selectable during registration/profile updates.
- For production, use HTTPS and secure database connections.
- Monitor RDS costs and EC2 usage.



_______________________-

SK