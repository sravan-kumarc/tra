

CREATE DATABASE IF NOT EXISTS college_portal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE college_portal;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password_hash VARCHAR(255),
  phone VARCHAR(20),
  course VARCHAR(100),
  status ENUM('active','inactive') DEFAULT 'active',
  role ENUM('student','admin') DEFAULT 'student',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) UNIQUE,
  description TEXT
);

CREATE TABLE student_details (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNIQUE,
  date_of_birth DATE,
  address TEXT,
  emergency_contact VARCHAR(100),
  emergency_phone VARCHAR(20),
  enrollment_year YEAR,
  gpa DECIMAL(3,2),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE assignments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  title VARCHAR(255),
  description TEXT,
  due_date DATE,
  status ENUM('pending','submitted','graded') DEFAULT 'pending',
  grade VARCHAR(10),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE,
  password_hash VARCHAR(255)
);

-- Insert pre-configured courses
INSERT INTO courses (name, description) VALUES
('Computer Science', 'Study of computers and computational systems'),
('Mechanical Engineering', 'Design and manufacturing of mechanical systems'),
('Electrical Engineering', 'Study of electrical systems and electronics'),
('Civil Engineering', 'Design and construction of infrastructure'),
('Business Administration', 'Management of business operations'),
('Medicine', 'Study of medical science and healthcare');

-- Insert default admin user
INSERT INTO admins (username, password_hash) VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

CREATE TABLE password_resets (
  token VARCHAR(255) PRIMARY KEY,
  email VARCHAR(100),
  expiry TIMESTAMP
);

CREATE TABLE logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  admin_id INT NULL,
  action VARCHAR(255),
  ip_address VARCHAR(45),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pre-configured courses offered by the college
INSERT INTO courses (name, description) VALUES
('Computer Science', 'Study of computers, software, and computational systems.'),
('Mechanical Engineering', 'Design, analysis, manufacturing, and maintenance of mechanical systems.'),
('Electrical Engineering', 'Study of electrical systems, electronics, and electromagnetism.'),
('Civil Engineering', 'Design, construction, and maintenance of physical infrastructure.'),
('Business Administration', 'Management of business operations and organizational leadership.'),
('Medicine', 'Study of medical sciences, diagnosis, and healthcare.');

-- Sample admin account
-- Default credentials: admin / password
INSERT INTO admins (username,password_hash) VALUES ('admin', 'password');
