<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
requireAdminLogin();

$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$activeUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE status='active'")->fetchColumn();

include("../includes/header.php");
?>

<div class="dashboard">
  <h2>Admin Dashboard</h2>
  <p>Welcome, <strong><?= htmlspecialchars($_SESSION['admin_username']) ?></strong>.</p>

  <div class="stats-grid">
    <div class="stat-card">
      <h3>Total Students</h3>
      <p><?= $totalUsers ?></p>
    </div>
    <div class="stat-card">
      <h3>Active Students</h3>
      <p><?= $activeUsers ?></p>
    </div>
  </div>

  <div class="action-grid">
    <a class="action-card" href="manage_users.php">Manage Students</a>
    <a class="action-card" href="view_logs.php">View Logs</a>
    <a class="action-card logout" href="logout.php">Logout</a>
  </div>
</div>

<?php include("../includes/footer.php"); ?>
