<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/logger.php");

if (isset($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password_hash'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        logAction($pdo, 'Admin logged in', null, $admin['id']);
        header('Location: dashboard.php');
        exit;
    }

    $error = 'Invalid admin username or password.';
}
?>

<?php include("../includes/header.php"); ?>

<div class="card-form">
  <h2>Admin Login</h2>
  <?php if (!empty($error)) echo flashMessage($error, 'danger'); ?>
  <form method="post" action="">
    <label for="username">Username</label>
    <input type="text" name="username" id="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>

    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>

    <button type="submit">Login</button>
  </form>
</div>

<?php include("../includes/footer.php"); ?>
