<?php
session_start();
require_once("../config/config.php");
require_once("../includes/logger.php");

if (isset($_SESSION['admin_id'])) {
    logAction($pdo, "Admin logged out", null, $_SESSION['admin_id']);
}
session_destroy();
header("Location: login.php");
