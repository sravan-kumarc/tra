<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/logger.php");
requireAdminLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $phone = sanitize($_POST['phone'] ?? '');
    $course = sanitize($_POST['course'] ?? '');

    if ($name === '' || $email === '' || $password === '') {
        $error = 'Name, email, and password are required.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'A student with that email already exists.';
        } else {
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash, phone, course, status, role, created_at) VALUES (?, ?, ?, ?, ?, 'active', 'student', NOW())");
            $stmt->execute([$name, $email, $passwordHash, $phone, $course]);
            logAction($pdo, 'Added new student', $pdo->lastInsertId(), $_SESSION['admin_id']);
            header('Location: manage_users.php');
            exit;
        }
    }
}

include("../includes/header.php");
?>

<div class="card-form">
  <h2>Add Student</h2>
  <?php if (!empty($error)) echo flashMessage($error, 'danger'); ?>
  <form method="POST" action="">
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>

    <label for="email">Email</label>
    <input type="email" name="email" id="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>

    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>

    <label for="phone">Phone</label>
    <input type="text" name="phone" id="phone" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">

    <label for="course">Course</label>
    <input type="text" name="course" id="course" value="<?= htmlspecialchars($_POST['course'] ?? '') ?>">

    <button type="submit">Add Student</button>
  </form>
</div>

<?php include("../includes/footer.php"); ?>
