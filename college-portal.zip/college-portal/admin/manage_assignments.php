<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
requireAdminLogin();

$users = $pdo->query("SELECT id, name, email FROM users ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = sanitize($_POST['user_id'] ?? '');
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $due_date = sanitize($_POST['due_date'] ?? '');

    if ($user_id && $title && $description && $due_date) {
        $stmt = $pdo->prepare("INSERT INTO assignments (user_id, title, description, due_date, status) VALUES (?, ?, ?, ?, 'pending')");
        $stmt->execute([$user_id, $title, $description, $due_date]);
        $success = 'Assignment added successfully.';
    } else {
        $error = 'All fields are required.';
    }
}

$assignments = $pdo->query("SELECT a.*, u.name as user_name FROM assignments a JOIN users u ON a.user_id = u.id ORDER BY a.due_date ASC")->fetchAll();

include("../includes/header.php");
?>

<div class="dashboard">
  <h2>Manage Assignments</h2>

  <div class="card-form">
    <h3>Add New Assignment</h3>
    <?php if (!empty($error)) echo flashMessage($error, 'danger'); ?>
    <?php if (!empty($success)) echo flashMessage($success); ?>
    <form method="POST" action="">
      <label for="user_id">Student</label>
      <select name="user_id" id="user_id" required>
        <option value="">Select a student</option>
        <?php foreach ($users as $user): ?>
          <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['name']) ?> (<?= htmlspecialchars($user['email']) ?>)</option>
        <?php endforeach; ?>
      </select>

      <label for="title">Title</label>
      <input type="text" name="title" id="title" required>

      <label for="description">Description</label>
      <textarea name="description" id="description" required></textarea>

      <label for="due_date">Due Date</label>
      <input type="date" name="due_date" id="due_date" required>

      <button type="submit">Add Assignment</button>
    </form>
  </div>

  <div class="assignments-section">
    <h3>All Assignments</h3>
    <?php if (empty($assignments)): ?>
      <p>No assignments yet.</p>
    <?php else: ?>
      <table class="data-table">
        <thead>
          <tr>
            <th>Student</th>
            <th>Title</th>
            <th>Description</th>
            <th>Due Date</th>
            <th>Status</th>
            <th>Grade</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($assignments as $assignment): ?>
            <tr>
              <td><?= htmlspecialchars($assignment['user_name']) ?></td>
              <td><?= htmlspecialchars($assignment['title']) ?></td>
              <td><?= htmlspecialchars(substr($assignment['description'], 0, 50)) ?>...</td>
              <td><?= htmlspecialchars($assignment['due_date']) ?></td>
              <td><?= htmlspecialchars($assignment['status']) ?></td>
              <td><?= htmlspecialchars($assignment['grade'] ?? 'N/A') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

<?php include("../includes/footer.php"); ?>