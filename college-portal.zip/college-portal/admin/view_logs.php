<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
requireAdminLogin();

$logs = $pdo->query("SELECT * FROM logs ORDER BY created_at DESC LIMIT 50")->fetchAll();
include("../includes/header.php");
?>

<div class="dashboard">
  <h2>System Logs</h2>
  <table class="data-table">
    <thead>
      <tr>
        <th>Time</th>
        <th>Action</th>
        <th>User</th>
        <th>Admin</th>
        <th>IP Address</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($logs as $log): ?>
        <tr>
          <td><?= htmlspecialchars($log['created_at']) ?></td>
          <td><?= htmlspecialchars($log['action']) ?></td>
          <td><?= htmlspecialchars($log['user_id']) ?></td>
          <td><?= htmlspecialchars($log['admin_id']) ?></td>
          <td><?= htmlspecialchars($log['ip_address']) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include("../includes/footer.php"); ?>
