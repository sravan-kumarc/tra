<?php
session_start();
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }
require_once("../config/config.php");
require_once("../includes/logger.php");

$id = $_GET['id'];
$stmt = $pdo->prepare("DELETE FROM users WHERE id=?");
$stmt->execute([$id]);

logAction($pdo, "Deleted user ID $id", null, $_SESSION['admin_id']);

header("Location: manage_users.php");
