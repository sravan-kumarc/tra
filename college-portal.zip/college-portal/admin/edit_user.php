<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/logger.php");
requireAdminLogin();

$id = intval($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    header('Location: manage_users.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $course = sanitize($_POST['course'] ?? '');
    $status = in_array($_POST['status'] ?? '', ['active', 'inactive']) ? $_POST['status'] : 'active';

    if ($name === '') {
        $error = 'Name cannot be empty.';
    } else {
        $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, course = ?, status = ? WHERE id = ?");
        $stmt->execute([$name, $phone, $course, $status, $id]);
        logAction($pdo, 'Updated student details', $id, $_SESSION['admin_id']);
        $success = 'Student details updated.';

        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch();
    }
}

include("../includes/header.php");
?>

<div class="card-form">
  <h2>Edit Student</h2>
  <?php if (!empty($error)) echo flashMessage($error, 'danger'); ?>
  <?php if (!empty($success)) echo flashMessage($success); ?>
  <form method="POST" action="?id=<?= $id ?>">
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="<?= htmlspecialchars($user['name']) ?>" required>

    <label for="phone">Phone</label>
    <input type="text" name="phone" id="phone" value="<?= htmlspecialchars($user['phone']) ?>">

    <label for="course">Course</label>
    <input type="text" name="course" id="course" value="<?= htmlspecialchars($user['course']) ?>">

    <label for="status">Status</label>
    <select name="status" id="status">
      <option value="active" <?= $user['status'] === 'active' ? 'selected' : '' ?>>Active</option>
      <option value="inactive" <?= $user['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
    </select>
    <button type="submit">Update Student</button>
  </form>
</div>

<?php include("../includes/footer.php"); ?>
