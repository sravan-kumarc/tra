<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
requireAdminLogin();

$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
include("../includes/header.php");
?>

<div class="dashboard">
  <h2>Manage Students</h2>
  <a class="button" href="add_user.php">Add Student</a>

  <table class="data-table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Course</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?= htmlspecialchars($u['id']) ?></td>
          <td><?= htmlspecialchars($u['name']) ?></td>
          <td><?= htmlspecialchars($u['email']) ?></td>
          <td><?= htmlspecialchars($u['course']) ?></td>
          <td><?= htmlspecialchars($u['status']) ?></td>
          <td>
            <a href="edit_user.php?id=<?= $u['id'] ?>">Edit</a>
            <a href="delete_user.php?id=<?= $u['id'] ?>" class="danger">Delete</a>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include("../includes/footer.php"); ?>
