<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/logger.php");

$token = sanitize($_GET['token'] ?? '');
if ($token === '') {
    die('Invalid password reset link.');
}

$stmt = $pdo->prepare("SELECT * FROM password_resets WHERE token = ? AND expiry > NOW()");
stmt->execute([$token]);
$reset = $stmt->fetch();

if (!$reset) {
    die('Invalid or expired password reset link.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';

    if ($password === '') {
        $error = 'Please enter a new password.';
    } else {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE email = ?");
        $stmt->execute([$passwordHash, $reset['email']]);

        $stmt = $pdo->prepare("DELETE FROM password_resets WHERE token = ?");
        $stmt->execute([$token]);

        logAction($pdo, 'Password reset completed');
        $success = 'Password updated successfully. <a href="login.php">Login</a>';
    }
}
?>

<?php include("../includes/header.php"); ?>

<div class="card-form">
  <h2>Reset Password</h2>
  <?php if (!empty($error)) echo flashMessage($error, 'danger'); ?>
  <?php if (!empty($success)) echo flashMessageRaw($success); ?>
  <?php if (empty($success)): ?>
  <form method="POST" action="?token=<?= htmlspecialchars($token) ?>">
    <label for="password">New Password</label>
    <input type="password" name="password" id="password" required>
    <button type="submit">Reset Password</button>
  </form>
  <?php endif; ?>
</div>

<?php include("../includes/footer.php"); ?>
