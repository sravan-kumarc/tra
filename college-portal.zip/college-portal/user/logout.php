<?php
session_start();
require_once("../config/config.php");
require_once("../includes/logger.php");

if (isset($_SESSION['user_id'])) {
    logAction($pdo, "User logged out", $_SESSION['user_id']);
}
session_destroy();
header("Location: login.php");
