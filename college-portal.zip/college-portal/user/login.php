<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/logger.php");

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email=? AND status='active'");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        logAction($pdo, 'User logged in', $user['id']);
        header('Location: dashboard.php');
        exit;
    }

    $error = 'Invalid email or password.';
}
?>

<?php include("../includes/header.php"); ?>

<div class="card-form">
  <h2>Student Login</h2>
  <?php if (!empty($error)) echo flashMessage($error, 'danger'); ?>
  <form method="post" action="">
    <label for="email">Email</label>
    <input type="email" name="email" id="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>

    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>

    <button type="submit">Login</button>
  </form>
  <p class="form-help">Don't have an account? <a href="register.php">Register</a></p>
  <p class="form-help"><a href="forgot_password.php">Forgot password?</a></p>
</div>

<?php include("../includes/footer.php"); ?>