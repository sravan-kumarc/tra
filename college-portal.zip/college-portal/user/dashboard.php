<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/logger.php");

requireUserLogin();

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM student_details WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$details = $stmt->fetch();

$assignments = $pdo->prepare("SELECT * FROM assignments WHERE user_id = ? ORDER BY due_date ASC");
$assignments->execute([$_SESSION['user_id']]);
$assignments = $assignments->fetchAll();

include("../includes/header.php");
?>

<div class="dashboard">
  <h2>Student Dashboard</h2>
  <p>Welcome, <strong><?= htmlspecialchars($user['name']) ?></strong>.</p>

  <div class="profile-card">
    <h3>Your Profile</h3>
    <p><strong>Name:</strong> <?= htmlspecialchars($user['name']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
    <p><strong>Phone:</strong> <?= htmlspecialchars($user['phone']) ?></p>
    <p><strong>Course:</strong> <?= htmlspecialchars($user['course']) ?></p>
    <p><strong>Status:</strong> <?= htmlspecialchars($user['status']) ?></p>
    <?php if ($details): ?>
      <p><strong>Date of Birth:</strong> <?= htmlspecialchars($details['date_of_birth']) ?></p>
      <p><strong>GPA:</strong> <?= htmlspecialchars($details['gpa']) ?></p>
    <?php endif; ?>
  </div>

  <div class="assignments-section">
    <h3>Your Assignments</h3>
    <?php if (empty($assignments)): ?>
      <p>No assignments yet.</p>
    <?php else: ?>
      <table class="data-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Due Date</th>
            <th>Status</th>
            <th>Grade</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($assignments as $assignment): ?>
            <tr>
              <td><?= htmlspecialchars($assignment['title']) ?></td>
              <td><?= htmlspecialchars(substr($assignment['description'], 0, 50)) ?>...</td>
              <td><?= htmlspecialchars($assignment['due_date']) ?></td>
              <td><?= htmlspecialchars($assignment['status']) ?></td>
              <td><?= htmlspecialchars($assignment['grade'] ?? 'N/A') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>

  <div class="action-grid">
    <a class="action-card" href="update_profile.php">Update Profile</a>
    <a class="action-card logout" href="logout.php">Logout</a>
  </div>
</div>

<?php include("../includes/footer.php"); ?>