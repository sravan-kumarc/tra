<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/logger.php");

requireUserLogin();

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

include("../includes/header.php");
?>

<div class="dashboard">
  <h2>Student Dashboard</h2>
  <p>Welcome, <strong><?= htmlspecialchars($user['name']) ?></strong>.</p>

  <div class="profile-card">
    <h3>Your Profile</h3>
    <p><strong>Name:</strong> <?= htmlspecialchars($user['name']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
    <p><strong>Phone:</strong> <?= htmlspecialchars($user['phone']) ?></p>
    <p><strong>Course:</strong> <?= htmlspecialchars($user['course']) ?></p>
    <p><strong>Status:</strong> <?= htmlspecialchars($user['status']) ?></p>
  </div>

  <div class="action-grid">
    <a class="action-card" href="update_profile.php">Update Profile</a>
    <a class="action-card" href="logout.php">Logout</a>
  </div>
</div>

<?php include("../includes/footer.php"); ?>