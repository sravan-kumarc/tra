<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/logger.php");

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$courses = $pdo->query("SELECT * FROM courses ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $phone = sanitize($_POST['phone'] ?? '');
    $course = sanitize($_POST['course'] ?? '');

    if ($name === '' || $email === '' || $password === '') {
        $error = 'Please complete all required fields.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'An account with that email already exists.';
        } else {
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name, email, password_hash, phone, course, status, role, created_at) VALUES (?, ?, ?, ?, ?, 'active', 'student', NOW())");
            $stmt->execute([$name, $email, $passwordHash, $phone, $course]);
            $userId = $pdo->lastInsertId();
            logAction($pdo, 'New student registered', $userId);
            $success = 'Registration successful. You can now log in.';
        }
    }
}
?>

<?php include("../includes/header.php"); ?>

<div class="card-form">
  <h2>Student Registration</h2>
  <?php if (!empty($error)) echo flashMessage($error, 'danger'); ?>
  <?php if (!empty($success)) echo flashMessage($success); ?>
  <form method="POST" action="">
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>

    <label for="email">Email</label>
    <input type="email" name="email" id="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>

    <label for="password">Password</label>
    <input type="password" name="password" id="password" required>

    <label for="phone">Phone</label>
    <input type="text" name="phone" id="phone" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">

    <label for="course">Course</label>
    <select name="course" id="course" required>
      <option value="">Select a course</option>
      <?php foreach ($courses as $c): ?>
        <option value="<?= htmlspecialchars($c['name']) ?>" <?= ($_POST['course'] ?? '') === $c['name'] ? 'selected' : '' ?>>
          <?= htmlspecialchars($c['name']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <button type="submit">Register</button>
  </form>
  <p class="form-help">Already have an account? <a href="login.php">Login here</a>.</p>
</div>

<?php include("../includes/footer.php"); ?>
