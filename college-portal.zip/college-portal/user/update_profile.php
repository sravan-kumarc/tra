<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/logger.php");

requireUserLogin();

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

$stmt = $pdo->prepare("SELECT * FROM student_details WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$details = $stmt->fetch();

$courses = $pdo->query("SELECT * FROM courses ORDER BY name")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $course = sanitize($_POST['course'] ?? '');
    $date_of_birth = sanitize($_POST['date_of_birth'] ?? '');
    $gpa = sanitize($_POST['gpa'] ?? '');

    if ($name === '') {
        $error = 'Name cannot be empty.';
    } else {
        $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, course = ? WHERE id = ?");
        $stmt->execute([$name, $phone, $course, $_SESSION['user_id']]);
        $_SESSION['user_name'] = $name;

        // Update or insert student details
        if ($details) {
            $stmt = $pdo->prepare("UPDATE student_details SET date_of_birth = ?, gpa = ? WHERE user_id = ?");
            $stmt->execute([$date_of_birth, $gpa, $_SESSION['user_id']]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO student_details (user_id, date_of_birth, gpa) VALUES (?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], $date_of_birth, $gpa]);
        }

        $success = 'Profile updated successfully.';
        logAction($pdo, 'Profile updated', $_SESSION['user_id']);

        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();

        $stmt = $pdo->prepare("SELECT * FROM student_details WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $details = $stmt->fetch();
    }
}
?>

<?php include("../includes/header.php"); ?>

<div class="card-form">
  <h2>Update Profile</h2>
  <?php if (!empty($error)) echo flashMessage($error, 'danger'); ?>
  <?php if (!empty($success)) echo flashMessage($success); ?>
  <form method="POST" action="">
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="<?= htmlspecialchars($user['name']) ?>" required>

    <label for="phone">Phone</label>
    <input type="text" name="phone" id="phone" value="<?= htmlspecialchars($user['phone']) ?>">

    <label for="course">Course</label>
    <select name="course" id="course">
      <option value="">Select a course</option>
      <?php foreach ($courses as $c): ?>
        <option value="<?= htmlspecialchars($c['name']) ?>" <?= $user['course'] === $c['name'] ? 'selected' : '' ?>>
          <?= htmlspecialchars($c['name']) ?>
        </option>
      <?php endforeach; ?>
    </select>

    <label for="date_of_birth">Date of Birth</label>
    <input type="date" name="date_of_birth" id="date_of_birth" value="<?= htmlspecialchars($details['date_of_birth'] ?? '') ?>">

    <label for="gpa">GPA</label>
    <input type="number" name="gpa" id="gpa" step="0.01" min="0" max="4" value="<?= htmlspecialchars($details['gpa'] ?? '') ?>">

    <button type="submit">Update Profile</button>
  </form>
</div>

<?php include("../includes/footer.php"); ?>
