<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/logger.php");

requireUserLogin();

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $course = sanitize($_POST['course'] ?? '');

    if ($name === '') {
        $error = 'Name cannot be empty.';
    } else {
        $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, course = ? WHERE id = ?");
        $stmt->execute([$name, $phone, $course, $_SESSION['user_id']]);
        $_SESSION['user_name'] = $name;
        $success = 'Profile updated successfully.';
        logAction($pdo, 'Profile updated', $_SESSION['user_id']);

        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
    }
}
?>

<?php include("../includes/header.php"); ?>

<div class="card-form">
  <h2>Update Profile</h2>
  <?php if (!empty($error)) echo flashMessage($error, 'danger'); ?>
  <?php if (!empty($success)) echo flashMessage($success); ?>
  <form method="POST" action="">
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="<?= htmlspecialchars($user['name']) ?>" required>

    <label for="phone">Phone</label>
    <input type="text" name="phone" id="phone" value="<?= htmlspecialchars($user['phone']) ?>">

    <label for="course">Course</label>
    <input type="text" name="course" id="course" value="<?= htmlspecialchars($user['course']) ?>">

    <button type="submit">Update Profile</button>
  </form>
</div>

<?php include("../includes/footer.php"); ?>
