<?php
session_start();
require_once("../config/config.php");
require_once("../includes/functions.php");
require_once("../includes/email.php");
require_once("../includes/logger.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');

    if ($email === '') {
        $error = 'Please provide your registered email address.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND status = 'active'");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            $token = bin2hex(random_bytes(16));
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $stmt = $pdo->prepare("INSERT INTO password_resets (token, email, expiry) VALUES (?, ?, ?)");
            $stmt->execute([$token, $email, $expiry]);

            $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
            $base = dirname($_SERVER['PHP_SELF']);
            $link = $scheme . '://' . $host . $base . '/reset_password.php?token=' . urlencode($token);
            if (sendEmail($email, 'College Portal Password Reset', "<p>Click the link below to reset your password:</p><p><a href='$link'>$link</a></p>")) {
                $success = 'A password reset link has been sent to your email.';
            } else {
                $success = 'Unable to send an email. Use this link to reset your password: <a href="' . htmlspecialchars($link) . '">' . htmlspecialchars($link) . '</a>';
            }

            logAction($pdo, 'Password reset requested', $user['id']);
        } else {
            $error = 'No active account found with that email.';
        }
    }
}
?>

<?php include("../includes/header.php"); ?>

<div class="card-form">
  <h2>Forgot Password</h2>
  <?php if (!empty($error)) echo flashMessage($error, 'danger'); ?>
  <?php if (!empty($success)) echo flashMessageRaw($success); ?>
  <form method="POST" action="">
    <label for="email">Registered Email</label>
    <input type="email" name="email" id="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
    <button type="submit">Send Reset Link</button>
  </form>
  <p class="form-help"><a href="login.php">Return to login</a></p>
</div>

<?php include("../includes/footer.php"); ?>
